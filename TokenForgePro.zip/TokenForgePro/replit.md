# TokenForge Pro

## Overview
TokenForge Pro is a production-ready fullstack web application for creating real SPL tokens on the Solana mainnet. The platform emphasizes simplicity, security, and ease of use with a clean, professional minimalist interface.

## Recent Changes
- **2025-10-18**: Initial setup complete with schema definition and all frontend components
  - Defined complete database schema for users and tokens
  - Created wallet connection context using Phantom wallet
  - Built 4-step wizard interface with progress indicators
  - Implemented token customization form with live preview
  - Created advanced options accordion (vanity address, multi-wallet, DEXTools, authorities)
  - Added dynamic fee counter with real-time SOL/USD conversion
  - Implemented onboarding modal for first-time users
  - Created user dashboard for viewing created tokens

## Project Architecture

### Tech Stack
**Frontend:**
- React 18 with TypeScript
- Wouter for routing
- TanStack Query for data fetching
- Shadcn UI components with Tailwind CSS
- Phantom Wallet integration for Solana

**Backend:**
- Node.js with Express
- TypeScript
- Drizzle ORM with PostgreSQL
- Solana Web3.js for blockchain interaction
- SPL Token for token minting
- Web3.Storage for IPFS metadata storage

**Blockchain:**
- Solana mainnet-beta
- SPL Token Program
- IPFS via Web3.Storage

### Key Features
1. **Wallet Integration**: Phantom Wallet connection with automatic reconnection
2. **4-Step Wizard**:
   - Step 1: Connect Wallet
   - Step 2: Customize Token (name, symbol, description, image, supply, decimals)
   - Step 3: Advanced Options (vanity address, multi-wallet distribution, DEXTools, authority revocations)
   - Step 4: Review & Mint
3. **Real-time Fee Calculation**: Dynamic SOL pricing with USD conversion via CoinGecko
4. **Live Token Preview**: Mock DEX listing card that updates as user types
5. **IPFS Metadata Storage**: Decentralized storage for token images and metadata
6. **Authority Management**: Ability to revoke freeze, mint, and update authorities
7. **User Dashboard**: View all created tokens with blockchain explorer links

### Pricing Structure
- Base token creation: 0.3 SOL
- Custom creator info: +0.1 SOL
- Vanity address (max 4 chars): +0.1 SOL
- Multi-wallet distribution (up to 10 wallets): +0.1 SOL
- DEXTools integration: +3.0 SOL
- Revoke freeze authority: +0.1 SOL
- Revoke mint authority: +0.1 SOL
- Revoke update authority: +0.1 SOL

### Database Schema
**users**:
- id (UUID primary key)
- walletAddress (unique Solana address)
- nonce (for signature verification)
- hasCompletedOnboarding (boolean)
- createdAt, updatedAt

**tokens**:
- id (UUID primary key)
- userId (foreign key to users)
- mintAddress (unique Solana token address)
- name, symbol, description, decimals, supply
- metadataUri, imageUri (IPFS links)
- Advanced option flags (hasCustomCreator, hasVanityAddress, etc.)
- Fee tracking (baseFee, totalFee, transactionSignature)
- createdAt

### API Endpoints
- `POST /api/auth/challenge`: Generate nonce for wallet signature
- `POST /api/auth/verify`: Verify signature and create session
- `POST /api/payment/verify`: Verify on-chain SOL payment
- `POST /api/tokens/register`: Mint token and upload metadata to IPFS
- `GET /api/user/tokens`: Fetch user's created tokens
- `GET /api/sol-price`: Get SOL/USD price from CoinGecko

## User Preferences
- **Design**: Minimalist, professional aesthetic with subdued color palette (grays, whites, blacks, subtle blues)
- **No neon colors, gradients, or flashy animations**
- **Inter font** for clean, readable typography
- **High contrast** for accessibility
- **Mobile-first responsive design** with ample whitespace

## Development Notes
- All components follow Shadcn UI patterns
- Uses Tailwind CSS custom elevation utilities (hover-elevate, active-elevate-2)
- Form validation with Zod schemas
- Real-time preview updates using React state
- Toast notifications for user feedback
- Automatic wallet reconnection on page load
- Theme toggle for light/dark mode

## Environment Variables
Required secrets:
- `DATABASE_URL`: PostgreSQL connection string
- `SOLANA_RPC_URL`: Solana mainnet RPC endpoint
- `WEB3_STORAGE_API_KEY`: Web3.Storage API key for IPFS uploads
- `SESSION_SECRET`: Express session secret

## TODO (Backend Implementation - Task 2)
- [ ] Set up PostgreSQL database with Drizzle
- [ ] Implement wallet signature verification
- [ ] Create SPL token minting logic
- [ ] Integrate IPFS metadata upload
- [ ] Add vanity address generation
- [ ] Implement multi-wallet distribution
- [ ] Add payment verification with on-chain memo checking
- [ ] Create all API endpoints

## TODO (Integration - Task 3)
- [ ] Connect frontend forms to backend APIs
- [ ] Test complete user flow from wallet connection to minting
- [ ] Add comprehensive error handling
- [ ] Implement loading states
- [ ] Test payment verification
- [ ] Verify IPFS uploads work correctly
