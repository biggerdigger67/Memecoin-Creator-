import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, integer, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// Users table - stores wallet addresses
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  walletAddress: text("wallet_address").notNull().unique(),
  nonce: text("nonce"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Sessions table - stores user sessions
export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Onboarding table - tracks onboarding completion anonymously
export const onboarding = pgTable("onboarding", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  completedAt: timestamp("completed_at").defaultNow().notNull(),
  skipped: boolean("skipped").default(false),
});

// Tokens table - stores created SPL tokens
export const tokens = pgTable("tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  
  // Token metadata
  mintAddress: text("mint_address").notNull().unique(),
  name: text("name").notNull(),
  symbol: text("symbol").notNull(),
  description: text("description"),
  decimals: integer("decimals").notNull().default(9),
  supply: text("supply").notNull(), // Stored as string to handle large numbers
  
  // IPFS metadata
  metadataUri: text("metadata_uri"),
  imageUri: text("image_uri"),
  
  // Advanced options
  hasCustomCreator: boolean("has_custom_creator").default(false),
  hasVanityAddress: boolean("has_vanity_address").default(false),
  vanityPrefix: text("vanity_prefix"),
  hasMultiWallet: boolean("has_multi_wallet").default(false),
  recipientWallets: jsonb("recipient_wallets").$type<{ address: string; amount: string }[]>(),
  hasDexTools: boolean("has_dex_tools").default(false),
  dexToolsData: jsonb("dex_tools_data").$type<{ twitter?: string; telegram?: string; website?: string; bannerUri?: string }>(),
  
  // Authority revocations
  freezeAuthorityRevoked: boolean("freeze_authority_revoked").default(false),
  mintAuthorityRevoked: boolean("mint_authority_revoked").default(false),
  updateAuthorityRevoked: boolean("update_authority_revoked").default(false),
  
  // Payment & fees
  baseFee: text("base_fee").notNull().default("0.3"),
  totalFee: text("total_fee").notNull(),
  transactionSignature: text("transaction_signature"),
  
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  tokens: many(tokens),
  sessions: many(sessions),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, {
    fields: [sessions.userId],
    references: [users.id],
  }),
}));

export const tokensRelations = relations(tokens, ({ one }) => ({
  user: one(users, {
    fields: [tokens.userId],
    references: [users.id],
  }),
}));

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const selectUserSchema = createSelectSchema(users);

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

export const selectSessionSchema = createSelectSchema(sessions);

export const insertOnboardingSchema = createInsertSchema(onboarding).omit({
  id: true,
  completedAt: true,
});

export const selectOnboardingSchema = createSelectSchema(onboarding);

export const insertTokenSchema = createInsertSchema(tokens).omit({
  id: true,
  createdAt: true,
}).extend({
  name: z.string().min(1, "Token name is required").max(32, "Token name must be 32 characters or less"),
  symbol: z.string().min(1, "Token symbol is required").max(10, "Token symbol must be 10 characters or less").toUpperCase(),
  description: z.string().max(200, "Description must be 200 characters or less").optional(),
  decimals: z.number().int().min(0).max(9).default(9),
  supply: z.string().min(1, "Supply is required"),
  vanityPrefix: z.string().max(4, "Vanity prefix must be 4 characters or less").optional(),
  recipientWallets: z.array(z.object({
    address: z.string().min(32, "Invalid wallet address"),
    amount: z.string().min(1, "Amount is required"),
  })).max(10, "Maximum 10 recipient wallets allowed").optional(),
});

export const selectTokenSchema = createSelectSchema(tokens);

// TypeScript types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;
export type InsertOnboarding = z.infer<typeof insertOnboardingSchema>;
export type Onboarding = typeof onboarding.$inferSelect;
export type InsertToken = z.infer<typeof insertTokenSchema>;
export type Token = typeof tokens.$inferSelect;

// API request/response types
export interface AuthChallengeRequest {
  walletAddress: string;
}

export interface AuthChallengeResponse {
  nonce: string;
  message: string;
}

export interface AuthVerifyRequest {
  walletAddress: string;
  signature: string;
}

export interface AuthVerifyResponse {
  success: boolean;
  user?: User;
}

export interface PaymentVerifyRequest {
  signature: string;
  amount: string;
}

export interface PaymentVerifyResponse {
  verified: boolean;
  transactionSignature?: string;
}

export interface TokenRegisterRequest extends Omit<InsertToken, 'userId' | 'mintAddress' | 'transactionSignature'> {
  imageFile?: File;
}

export interface TokenRegisterResponse {
  success: boolean;
  token?: Token;
  mintAddress?: string;
  error?: string;
}

export interface SolPriceResponse {
  solana: {
    usd: number;
  };
}
