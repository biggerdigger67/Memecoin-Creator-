import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface WalletContextType {
  walletAddress: string | null;
  isConnected: boolean;
  connecting: boolean;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  balance: number | null;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [balance, setBalance] = useState<number | null>(null);

  const isConnected = !!walletAddress;

  // Check if Phantom is installed
  const getPhantomProvider = () => {
    if ('phantom' in window) {
      const provider = (window as any).phantom?.solana;
      if (provider?.isPhantom) {
        return provider;
      }
    }
    return null;
  };

  // Connect wallet
  const connectWallet = async () => {
    setConnecting(true);
    try {
      const provider = getPhantomProvider();
      
      if (!provider) {
        window.open('https://phantom.app/', '_blank');
        throw new Error('Phantom wallet is not installed. Please install it to continue.');
      }

      const response = await provider.connect();
      const address = response.publicKey.toString();
      setWalletAddress(address);
      
      // Get balance
      await fetchBalance(provider, response.publicKey);
      
      // Store in localStorage
      localStorage.setItem('walletAddress', address);
    } catch (error: any) {
      console.error('Failed to connect wallet:', error);
      throw error;
    } finally {
      setConnecting(false);
    }
  };

  // Disconnect wallet
  const disconnectWallet = () => {
    const provider = getPhantomProvider();
    if (provider) {
      provider.disconnect();
    }
    setWalletAddress(null);
    setBalance(null);
    localStorage.removeItem('walletAddress');
  };

  // Fetch balance
  const fetchBalance = async (provider: any, publicKey: any) => {
    try {
      const balanceLamports = await provider.connection.getBalance(publicKey);
      const balanceSOL = balanceLamports / 1e9;
      setBalance(balanceSOL);
    } catch (error) {
      console.error('Failed to fetch balance:', error);
    }
  };

  // Auto-connect on mount if previously connected
  useEffect(() => {
    const storedAddress = localStorage.getItem('walletAddress');
    if (storedAddress) {
      const provider = getPhantomProvider();
      if (provider) {
        provider.connect({ onlyIfTrusted: true })
          .then((response: any) => {
            setWalletAddress(response.publicKey.toString());
            fetchBalance(provider, response.publicKey);
          })
          .catch(() => {
            localStorage.removeItem('walletAddress');
          });
      }
    }
  }, []);

  // Listen for account changes
  useEffect(() => {
    const provider = getPhantomProvider();
    if (provider) {
      provider.on('accountChanged', (publicKey: any) => {
        if (publicKey) {
          setWalletAddress(publicKey.toString());
          fetchBalance(provider, publicKey);
        } else {
          disconnectWallet();
        }
      });

      provider.on('disconnect', () => {
        disconnectWallet();
      });
    }
  }, []);

  return (
    <WalletContext.Provider
      value={{
        walletAddress,
        isConnected,
        connecting,
        connectWallet,
        disconnectWallet,
        balance,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
}
