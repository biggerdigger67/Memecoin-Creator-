import { useState } from 'react';
import { Loader2, CheckCircle2, ExternalLink, AlertCircle } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { TokenFormData } from '@/pages/CreateToken';
import { calculateTotalFee, formatSolAmount } from '@/lib/solana';
import { useWallet } from '@/contexts/WalletContext';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

interface StepMintProps {
  formData: TokenFormData;
  onBack: () => void;
}

export function StepMint({ formData, onBack }: StepMintProps) {
  const { walletAddress, balance } = useWallet();
  const { toast } = useToast();
  const [mintAddress, setMintAddress] = useState<string | null>(null);
  const [transactionSignature, setTransactionSignature] = useState<string | null>(null);

  const totalFee = calculateTotalFee({
    hasCustomCreator: formData.hasCustomCreator,
    hasVanityAddress: formData.hasVanityAddress,
    hasMultiWallet: formData.hasMultiWallet,
    hasDexTools: formData.hasDexTools,
    freezeAuthorityRevoked: formData.freezeAuthorityRevoked,
    mintAuthorityRevoked: formData.mintAuthorityRevoked,
    updateAuthorityRevoked: formData.updateAuthorityRevoked,
  });

  const insufficientBalance = balance !== null && balance < totalFee;

  const mintMutation = useMutation({
    mutationFn: async () => {
      // Create FormData for file upload
      const formDataToSend = new FormData();
      formDataToSend.append('name', formData.name);
      formDataToSend.append('symbol', formData.symbol);
      formDataToSend.append('description', formData.description || '');
      formDataToSend.append('decimals', formData.decimals.toString());
      formDataToSend.append('supply', formData.supply);
      formDataToSend.append('totalFee', totalFee.toString());

      if (formData.imageFile) {
        formDataToSend.append('image', formData.imageFile);
      }

      // Advanced options
      formDataToSend.append('hasCustomCreator', formData.hasCustomCreator.toString());
      formDataToSend.append('hasVanityAddress', formData.hasVanityAddress.toString());
      formDataToSend.append('hasMultiWallet', formData.hasMultiWallet.toString());
      formDataToSend.append('hasDexTools', formData.hasDexTools.toString());
      formDataToSend.append('freezeAuthorityRevoked', formData.freezeAuthorityRevoked.toString());
      formDataToSend.append('mintAuthorityRevoked', formData.mintAuthorityRevoked.toString());
      formDataToSend.append('updateAuthorityRevoked', formData.updateAuthorityRevoked.toString());

      if (formData.hasVanityAddress) {
        formDataToSend.append('vanityPrefix', formData.vanityPrefix);
      }

      if (formData.hasMultiWallet) {
        formDataToSend.append('recipientWallets', JSON.stringify(formData.recipientWallets));
      }

      if (formData.hasDexTools) {
        formDataToSend.append('dexToolsData', JSON.stringify({
          twitter: formData.dexToolsTwitter,
          telegram: formData.dexToolsTelegram,
          website: formData.dexToolsWebsite,
        }));
      }

      const response = await fetch('/api/tokens/register', {
        method: 'POST',
        body: formDataToSend,
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to mint token');
      }

      return response.json();
    },
    onSuccess: (data) => {
      setMintAddress(data.mintAddress);
      setTransactionSignature(data.transactionSignature);
      toast({
        title: 'Token minted successfully!',
        description: 'Your SPL token has been created on Solana mainnet',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Minting failed',
        description: error.message || 'An error occurred while minting your token',
        variant: 'destructive',
      });
    },
  });

  const handleMint = () => {
    if (insufficientBalance) {
      toast({
        title: 'Insufficient balance',
        description: `You need at least ${formatSolAmount(totalFee)} to create this token`,
        variant: 'destructive',
      });
      return;
    }

    mintMutation.mutate();
  };

  if (mintMutation.isSuccess && mintAddress) {
    return (
      <Card className="p-8">
        <div className="space-y-6 text-center">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-chart-2/10">
            <CheckCircle2 className="h-10 w-10 text-chart-2" />
          </div>

          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Token Created!</h2>
            <p className="text-muted-foreground">
              Your SPL token has been successfully minted on Solana mainnet
            </p>
          </div>

          <div className="space-y-3 rounded-md bg-muted/50 p-4">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Mint Address</p>
              <p className="font-mono text-sm font-medium break-all" data-testid="text-mint-address">
                {mintAddress}
              </p>
            </div>

            {transactionSignature && (
              <div className="space-y-1">
                <p className="text-xs text-muted-foreground">Transaction</p>
                <a
                  href={`https://solscan.io/tx/${transactionSignature}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 font-mono text-sm font-medium text-primary hover:underline"
                  data-testid="link-transaction"
                >
                  View on Solscan <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            )}
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onBack}
              className="flex-1 hover-elevate active-elevate-2"
              data-testid="button-create-another"
            >
              Create Another Token
            </Button>
            <Button
              onClick={() => window.open(`https://solscan.io/token/${mintAddress}`, '_blank')}
              className="flex-1 hover-elevate active-elevate-2"
              data-testid="button-view-token-explorer"
            >
              View on Explorer
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-8">
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Review & Mint</h2>
          <p className="text-muted-foreground">Review your token details and mint it to Solana mainnet</p>
        </div>

        {/* Balance Warning */}
        {insufficientBalance && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Insufficient SOL balance. You need {formatSolAmount(totalFee)} but only have{' '}
              {balance !== null ? formatSolAmount(balance) : '0 SOL'}. Top up your wallet on{' '}
              <a
                href="https://www.binance.com"
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium underline"
              >
                Binance
              </a>
              ,{' '}
              <a
                href="https://www.coinbase.com"
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium underline"
              >
                Coinbase
              </a>
              , or another exchange.
            </AlertDescription>
          </Alert>
        )}

        {/* Token Summary */}
        <div className="space-y-3 rounded-md border p-4">
          <h3 className="font-semibold">Token Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Name</span>
              <span className="font-medium">{formData.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Symbol</span>
              <span className="font-medium">{formData.symbol}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Supply</span>
              <span className="font-medium">{formData.supply}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Decimals</span>
              <span className="font-medium">{formData.decimals}</span>
            </div>
          </div>
        </div>

        {/* Fee Summary */}
        <div className="space-y-3 rounded-md border p-4">
          <h3 className="font-semibold">Fee Breakdown</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Base Fee</span>
              <span className="font-medium">0.3 SOL</span>
            </div>
            {formData.freezeAuthorityRevoked && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Revoke Freeze Authority</span>
                <span className="font-medium">+0.1 SOL</span>
              </div>
            )}
            {formData.mintAuthorityRevoked && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Revoke Mint Authority</span>
                <span className="font-medium">+0.1 SOL</span>
              </div>
            )}
            {formData.updateAuthorityRevoked && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Revoke Update Authority</span>
                <span className="font-medium">+0.1 SOL</span>
              </div>
            )}
            {formData.hasVanityAddress && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Vanity Address</span>
                <span className="font-medium">+0.1 SOL</span>
              </div>
            )}
            {formData.hasMultiWallet && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Multi-Wallet Distribution</span>
                <span className="font-medium">+0.1 SOL</span>
              </div>
            )}
            {formData.hasDexTools && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">DEXTools Integration</span>
                <span className="font-medium">+3.0 SOL</span>
              </div>
            )}
            <div className="flex justify-between border-t pt-2">
              <span className="font-semibold">Total</span>
              <span className="text-lg font-bold text-primary">{formatSolAmount(totalFee)}</span>
            </div>
          </div>
        </div>

        {/* Navigation buttons */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onBack}
            disabled={mintMutation.isPending}
            className="hover-elevate active-elevate-2"
            data-testid="button-mint-back"
          >
            Back
          </Button>
          <Button
            onClick={handleMint}
            disabled={mintMutation.isPending || insufficientBalance}
            className="flex-1 hover-elevate active-elevate-2"
            data-testid="button-mint-token"
          >
          {mintMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Minting Token...
            </>
          ) : (
            `Mint Token for ${formatSolAmount(totalFee)}`
          )}
          </Button>
        </div>

        <p className="text-center text-xs text-muted-foreground">
          By minting, you agree to pay the total fee. This action cannot be undone.
        </p>
      </div>
    </Card>
  );
}
