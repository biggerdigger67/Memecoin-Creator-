import { Wallet, Shield, Zap } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useWallet } from '@/contexts/WalletContext';
import { useEffect } from 'react';

interface StepConnectProps {
  onNext: () => void;
}

export function StepConnect({ onNext }: StepConnectProps) {
  const { isConnected, connecting, connectWallet } = useWallet();

  useEffect(() => {
    if (isConnected) {
      onNext();
    }
  }, [isConnected, onNext]);

  const features = [
    {
      icon: Shield,
      title: 'Secure & Verified',
      description: 'All transactions are secured by Solana mainnet-beta blockchain',
    },
    {
      icon: Zap,
      title: 'Fast Creation',
      description: 'Create and deploy SPL tokens in minutes, not hours',
    },
    {
      icon: Wallet,
      title: 'Full Ownership',
      description: 'You retain complete control over your token and its authorities',
    },
  ];

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <Card className="p-8">
        <div className="space-y-6 text-center">
          {/* Icon */}
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-primary/10">
            <Wallet className="h-10 w-10 text-primary" />
          </div>

          {/* Title */}
          <div className="space-y-2">
            <h2 className="text-3xl font-bold tracking-tight">Connect Your Wallet</h2>
            <p className="text-muted-foreground">
              Connect your Phantom Wallet to start creating SPL tokens on Solana mainnet
            </p>
          </div>

          {/* Connect button */}
          <Button
            size="lg"
            onClick={connectWallet}
            disabled={connecting}
            className="w-full max-w-xs hover-elevate active-elevate-2"
            data-testid="button-connect-phantom"
          >
            <Wallet className="mr-2 h-5 w-5" />
            {connecting ? 'Connecting...' : 'Connect Phantom Wallet'}
          </Button>

          {/* Help text */}
          <p className="text-sm text-muted-foreground">
            Don't have Phantom?{' '}
            <a
              href="https://phantom.app/"
              target="_blank"
              rel="noopener noreferrer"
              className="font-medium text-primary hover:underline"
            >
              Download it here
            </a>
          </p>
        </div>
      </Card>

      {/* Features */}
      <div className="grid gap-4 sm:grid-cols-3">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <Card key={index} className="p-4">
              <div className="space-y-2 text-center">
                <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold">{feature.title}</h3>
                <p className="text-xs text-muted-foreground">{feature.description}</p>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
