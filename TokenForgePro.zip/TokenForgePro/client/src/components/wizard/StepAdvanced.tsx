import { Plus, Trash2, ChevronDown } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import { TokenFormData } from '@/pages/CreateToken';
import { ADVANCED_FEES } from '@/lib/solana';

interface StepAdvancedProps {
  formData: TokenFormData;
  updateFormData: (updates: Partial<TokenFormData>) => void;
  onNext: () => void;
  onBack: () => void;
}

export function StepAdvanced({ formData, updateFormData, onNext, onBack }: StepAdvancedProps) {
  const addRecipientWallet = () => {
    if (formData.recipientWallets.length < 10) {
      updateFormData({
        recipientWallets: [...formData.recipientWallets, { address: '', amount: '' }],
      });
    }
  };

  const removeRecipientWallet = (index: number) => {
    const wallets = formData.recipientWallets.filter((_, i) => i !== index);
    updateFormData({
      recipientWallets: wallets.length > 0 ? wallets : [{ address: '', amount: '' }],
    });
  };

  const updateRecipientWallet = (index: number, field: 'address' | 'amount', value: string) => {
    const wallets = [...formData.recipientWallets];
    wallets[index] = { ...wallets[index], [field]: value };
    updateFormData({ recipientWallets: wallets });
  };

  return (
    <Card className="p-6">
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Advanced Options</h2>
          <p className="text-muted-foreground">Customize your token with advanced features</p>
        </div>

        {/* Authority Revocations - Always Visible */}
        <div className="space-y-4 rounded-md border p-4">
          <div>
            <h3 className="text-lg font-semibold">Authority Management</h3>
            <p className="text-sm text-muted-foreground">Revoke authorities to make your token immutable</p>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="freeze-authority">Revoke Freeze Authority</Label>
                <p className="text-xs text-muted-foreground">Prevent freezing token accounts</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">+{ADVANCED_FEES.revokeFreeze} SOL</Badge>
                <Switch
                  id="freeze-authority"
                  checked={formData.freezeAuthorityRevoked}
                  onCheckedChange={(checked) => updateFormData({ freezeAuthorityRevoked: checked })}
                  data-testid="switch-revoke-freeze"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="mint-authority">Revoke Mint Authority</Label>
                <p className="text-xs text-muted-foreground">Prevent minting additional tokens</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">+{ADVANCED_FEES.revokeMint} SOL</Badge>
                <Switch
                  id="mint-authority"
                  checked={formData.mintAuthorityRevoked}
                  onCheckedChange={(checked) => updateFormData({ mintAuthorityRevoked: checked })}
                  data-testid="switch-revoke-mint"
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="update-authority">Revoke Update Authority</Label>
                <p className="text-xs text-muted-foreground">Prevent metadata updates</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">+{ADVANCED_FEES.revokeUpdate} SOL</Badge>
                <Switch
                  id="update-authority"
                  checked={formData.updateAuthorityRevoked}
                  onCheckedChange={(checked) => updateFormData({ updateAuthorityRevoked: checked })}
                  data-testid="switch-revoke-update"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Other Advanced Options - Accordion */}
        <Accordion type="single" collapsible className="w-full">
          {/* Vanity Address */}
          <AccordionItem value="vanity">
            <AccordionTrigger className="hover:no-underline" data-testid="accordion-trigger-vanity">
              <div className="flex items-center gap-2">
                <span>Vanity Address Generator</span>
                <Badge variant="outline" className="text-xs">+{ADVANCED_FEES.vanityAddress} SOL</Badge>
                {formData.hasVanityAddress && <Badge className="text-xs">Active</Badge>}
              </div>
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4 pt-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="vanity-enable">Enable Vanity Address</Label>
                  <Switch
                    id="vanity-enable"
                    checked={formData.hasVanityAddress}
                    onCheckedChange={(checked) => updateFormData({ hasVanityAddress: checked })}
                    data-testid="switch-vanity-address"
                  />
                </div>

                {formData.hasVanityAddress && (
                  <div className="space-y-2">
                    <Label htmlFor="vanity-prefix">Prefix (max 4 characters)</Label>
                    <Input
                      id="vanity-prefix"
                      value={formData.vanityPrefix}
                      onChange={(e) => updateFormData({ vanityPrefix: e.target.value.slice(0, 4) })}
                      placeholder="COOL"
                      maxLength={4}
                      data-testid="input-vanity-prefix"
                    />
                    <p className="text-xs text-muted-foreground">
                      Your token address will start with this prefix
                    </p>
                  </div>
                )}
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* Multi-Wallet Distribution */}
          <AccordionItem value="multi-wallet">
            <AccordionTrigger className="hover:no-underline" data-testid="accordion-trigger-multi-wallet">
              <div className="flex items-center gap-2">
                <span>Multi-Wallet Distribution</span>
                <Badge variant="outline" className="text-xs">+{ADVANCED_FEES.multiWallet} SOL</Badge>
                {formData.hasMultiWallet && <Badge className="text-xs">Active</Badge>}
              </div>
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4 pt-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="multi-wallet-enable">Enable Multi-Wallet</Label>
                  <Switch
                    id="multi-wallet-enable"
                    checked={formData.hasMultiWallet}
                    onCheckedChange={(checked) => updateFormData({ hasMultiWallet: checked })}
                    data-testid="switch-multi-wallet"
                  />
                </div>

                {formData.hasMultiWallet && (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      Distribute tokens to up to 10 different wallets (max {formData.recipientWallets.length}/10)
                    </p>

                    {formData.recipientWallets.map((wallet, index) => (
                      <div key={index} className="flex gap-2">
                        <Input
                          placeholder="Wallet address"
                          value={wallet.address}
                          onChange={(e) => updateRecipientWallet(index, 'address', e.target.value)}
                          data-testid={`input-recipient-address-${index}`}
                        />
                        <Input
                          placeholder="Amount"
                          type="number"
                          value={wallet.amount}
                          onChange={(e) => updateRecipientWallet(index, 'amount', e.target.value)}
                          className="w-32"
                          data-testid={`input-recipient-amount-${index}`}
                        />
                        {formData.recipientWallets.length > 1 && (
                          <Button
                            size="icon"
                            variant="outline"
                            onClick={() => removeRecipientWallet(index)}
                            data-testid={`button-remove-recipient-${index}`}
                            className="hover-elevate active-elevate-2"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    ))}

                    {formData.recipientWallets.length < 10 && (
                      <Button
                        variant="outline"
                        onClick={addRecipientWallet}
                        className="w-full hover-elevate active-elevate-2"
                        data-testid="button-add-recipient"
                      >
                        <Plus className="mr-2 h-4 w-4" />
                        Add Recipient
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </AccordionContent>
          </AccordionItem>

          {/* DEXTools Integration */}
          <AccordionItem value="dextools">
            <AccordionTrigger className="hover:no-underline" data-testid="accordion-trigger-dextools">
              <div className="flex items-center gap-2">
                <span>DEXTools Integration</span>
                <Badge variant="outline" className="text-xs">+{ADVANCED_FEES.dexTools} SOL</Badge>
                {formData.hasDexTools && <Badge className="text-xs">Active</Badge>}
              </div>
            </AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4 pt-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="dextools-enable">Enable DEXTools Integration</Label>
                  <Switch
                    id="dextools-enable"
                    checked={formData.hasDexTools}
                    onCheckedChange={(checked) => updateFormData({ hasDexTools: checked })}
                    data-testid="switch-dextools"
                  />
                </div>

                {formData.hasDexTools && (
                  <div className="space-y-3">
                    <div className="space-y-2">
                      <Label htmlFor="twitter">Twitter URL</Label>
                      <Input
                        id="twitter"
                        value={formData.dexToolsTwitter}
                        onChange={(e) => updateFormData({ dexToolsTwitter: e.target.value })}
                        placeholder="https://twitter.com/yourtoken"
                        data-testid="input-dextools-twitter"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="telegram">Telegram URL</Label>
                      <Input
                        id="telegram"
                        value={formData.dexToolsTelegram}
                        onChange={(e) => updateFormData({ dexToolsTelegram: e.target.value })}
                        placeholder="https://t.me/yourtoken"
                        data-testid="input-dextools-telegram"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="website">Website URL</Label>
                      <Input
                        id="website"
                        value={formData.dexToolsWebsite}
                        onChange={(e) => updateFormData({ dexToolsWebsite: e.target.value })}
                        placeholder="https://yourtoken.com"
                        data-testid="input-dextools-website"
                      />
                    </div>
                  </div>
                )}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        {/* Navigation buttons */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onBack}
            className="hover-elevate active-elevate-2"
            data-testid="button-advanced-back"
          >
            Back
          </Button>
          <Button
            onClick={onNext}
            className="flex-1 hover-elevate active-elevate-2"
            data-testid="button-advanced-next"
          >
            Review & Mint Token
          </Button>
        </div>
      </div>
    </Card>
  );
}
