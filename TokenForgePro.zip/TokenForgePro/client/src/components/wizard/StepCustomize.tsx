import { useState } from 'react';
import { Upload, X } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { TokenPreview } from '@/components/TokenPreview';
import { TokenFormData } from '@/pages/CreateToken';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { insertTokenSchema } from '@shared/schema';
import { z } from 'zod';

const customizeFormSchema = insertTokenSchema.pick({
  name: true,
  symbol: true,
  description: true,
  decimals: true,
  supply: true,
});

type CustomizeFormValues = z.infer<typeof customizeFormSchema>;

interface StepCustomizeProps {
  formData: TokenFormData;
  updateFormData: (updates: Partial<TokenFormData>) => void;
  onNext: () => void;
  onBack: () => void;
}

export function StepCustomize({ formData, updateFormData, onNext, onBack }: StepCustomizeProps) {
  const { toast } = useToast();

  const form = useForm<CustomizeFormValues>({
    resolver: zodResolver(customizeFormSchema),
    defaultValues: {
      name: formData.name,
      symbol: formData.symbol,
      description: formData.description || '',
      decimals: formData.decimals,
      supply: formData.supply,
    },
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      toast({
        title: 'File too large',
        description: 'Image must be less than 2MB',
        variant: 'destructive',
      });
      return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Invalid file type',
        description: 'Please upload an image file',
        variant: 'destructive',
      });
      return;
    }

    // Create preview URL
    const reader = new FileReader();
    reader.onloadend = () => {
      updateFormData({
        imageFile: file,
        imagePreview: reader.result as string,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    updateFormData({
      imageFile: null,
      imagePreview: '',
    });
  };

  const onSubmit = (values: CustomizeFormValues) => {
    updateFormData(values);
    onNext();
  };

  // Update parent state as form values change
  const watchedValues = form.watch();
  const updateParent = (field: keyof CustomizeFormValues, value: any) => {
    updateFormData({ [field]: value });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Form */}
      <Card className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Customize Your Token</h2>
              <p className="text-muted-foreground">Enter your token details and preview how it will appear</p>
            </div>

            {/* Token Name */}
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Token Name *</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="My Awesome Token"
                      maxLength={32}
                      data-testid="input-token-name"
                      onChange={(e) => {
                        field.onChange(e);
                        updateParent('name', e.target.value);
                      }}
                    />
                  </FormControl>
                  <FormDescription>{field.value?.length || 0}/32 characters</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Token Symbol */}
            <FormField
              control={form.control}
              name="symbol"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Token Symbol *</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="MAT"
                      maxLength={10}
                      data-testid="input-token-symbol"
                      onChange={(e) => {
                        const value = e.target.value.toUpperCase();
                        field.onChange(value);
                        updateParent('symbol', value);
                      }}
                    />
                  </FormControl>
                  <FormDescription>{field.value?.length || 0}/10 characters</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      placeholder="Describe your token..."
                      maxLength={200}
                      rows={3}
                      data-testid="input-token-description"
                      onChange={(e) => {
                        field.onChange(e);
                        updateParent('description', e.target.value);
                      }}
                    />
                  </FormControl>
                  <FormDescription>{field.value?.length || 0}/200 characters</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Supply and Decimals */}
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="supply"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Total Supply *</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="number"
                        placeholder="1000000"
                        min="1"
                        data-testid="input-token-supply"
                        onChange={(e) => {
                          field.onChange(e.target.value);
                          updateParent('supply', e.target.value);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="decimals"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Decimals</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="number"
                        min="0"
                        max="9"
                        data-testid="input-token-decimals"
                        onChange={(e) => {
                          const value = parseInt(e.target.value) || 9;
                          field.onChange(value);
                          updateParent('decimals', value);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Image Upload */}
            <div className="space-y-2">
              <Label>Token Image</Label>
              {formData.imagePreview ? (
                <div className="relative">
                  <img
                    src={formData.imagePreview}
                    alt="Token preview"
                    className="h-32 w-32 rounded-md border object-cover"
                  />
                  <Button
                    type="button"
                    size="icon"
                    variant="destructive"
                    onClick={handleRemoveImage}
                    className="absolute -right-2 -top-2 h-6 w-6 rounded-full hover-elevate active-elevate-2"
                    data-testid="button-remove-image"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div className="relative">
                  <input
                    type="file"
                    id="image"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                    data-testid="input-token-image"
                  />
                  <Label
                    htmlFor="image"
                    className="flex h-32 w-full cursor-pointer flex-col items-center justify-center rounded-md border-2 border-dashed border-border hover-elevate active-elevate-2"
                    data-testid="label-upload-image"
                  >
                    <Upload className="h-8 w-8 text-muted-foreground" />
                    <span className="mt-2 text-sm text-muted-foreground">Upload image (max 2MB)</span>
                  </Label>
                </div>
              )}
            </div>

            {/* Navigation buttons */}
            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onBack}
                className="hover-elevate active-elevate-2"
                data-testid="button-customize-back"
              >
                Back
              </Button>
              <Button
                type="submit"
                className="flex-1 hover-elevate active-elevate-2"
                data-testid="button-customize-next"
              >
                Continue to Advanced Options
              </Button>
            </div>
          </form>
        </Form>
      </Card>

      {/* Preview */}
      <div className="hidden lg:block">
        <div className="sticky top-20">
          <div className="mb-4">
            <h3 className="text-lg font-semibold">Live Preview</h3>
            <p className="text-sm text-muted-foreground">See how your token will appear on DEX platforms</p>
          </div>
          <TokenPreview
            name={watchedValues.name || ''}
            symbol={watchedValues.symbol || ''}
            description={watchedValues.description || ''}
            imageUrl={formData.imagePreview}
            supply={watchedValues.supply || ''}
            decimals={watchedValues.decimals || 9}
          />
        </div>
      </div>
    </div>
  );
}
