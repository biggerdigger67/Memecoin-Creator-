import { Wallet, Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useWallet } from '@/contexts/WalletContext';
import { useTheme } from '@/contexts/ThemeContext';
import { truncateAddress, formatSolAmount } from '@/lib/solana';

export function Header() {
  const { walletAddress, isConnected, connecting, connectWallet, disconnectWallet, balance } = useWallet();
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary">
            <span className="text-lg font-bold text-primary-foreground">T</span>
          </div>
          <span className="text-xl font-semibold tracking-tight">TokenForge Pro</span>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          {/* Theme Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            data-testid="button-theme-toggle"
            className="hover-elevate active-elevate-2"
          >
            {theme === 'light' ? (
              <Moon className="h-5 w-5" />
            ) : (
              <Sun className="h-5 w-5" />
            )}
            <span className="sr-only">Toggle theme</span>
          </Button>

          {/* Wallet Connection */}
          {isConnected ? (
            <div className="flex items-center gap-2">
              {balance !== null && (
                <span className="hidden text-sm text-muted-foreground sm:inline" data-testid="text-wallet-balance">
                  {formatSolAmount(balance)}
                </span>
              )}
              <Button
                variant="outline"
                onClick={disconnectWallet}
                data-testid="button-disconnect-wallet"
                className="hover-elevate active-elevate-2"
              >
                <Wallet className="mr-2 h-4 w-4" />
                <span className="hidden sm:inline">{truncateAddress(walletAddress!)}</span>
                <span className="sm:hidden">Disconnect</span>
              </Button>
            </div>
          ) : (
            <Button
              onClick={connectWallet}
              disabled={connecting}
              data-testid="button-connect-wallet"
              className="hover-elevate active-elevate-2"
            >
              <Wallet className="mr-2 h-4 w-4" />
              {connecting ? 'Connecting...' : 'Connect Phantom'}
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
