import { useState, useEffect } from 'react';
import { X, Wallet, Sparkles, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

export function OnboardingModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    // Check if user has seen onboarding
    const hasSeenOnboarding = localStorage.getItem('hasSeenOnboarding');
    if (!hasSeenOnboarding) {
      setIsOpen(true);
    }
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    localStorage.setItem('hasSeenOnboarding', 'true');
  };

  const handleNext = () => {
    if (currentStep < 2) {
      setCurrentStep(currentStep + 1);
    } else {
      handleClose();
    }
  };

  const handleSkip = () => {
    handleClose();
  };

  const steps = [
    {
      icon: Wallet,
      title: 'Connect Your Wallet',
      description: 'Connect your Phantom Wallet to seamlessly access Solana mainnet and start creating tokens.',
    },
    {
      icon: Sparkles,
      title: 'Explore Token Creation',
      description: 'Input your token name, symbol, and description. Upload an image and preview how your token will appear.',
    },
    {
      icon: DollarSign,
      title: 'View Pricing',
      description: 'Base fee is 0.3 SOL. Add advanced options like vanity addresses (+0.1 SOL), multi-wallet distribution (+0.1 SOL), or DEXTools integration (+3 SOL).',
    },
  ];

  if (!isOpen) return null;

  const currentStepData = steps[currentStep];
  const Icon = currentStepData.icon;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
      <Card className="relative w-full max-w-md p-8 shadow-lg">
        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute right-4 top-4 rounded-md p-1 hover-elevate active-elevate-2"
          data-testid="button-close-onboarding"
        >
          <X className="h-5 w-5 text-muted-foreground" />
          <span className="sr-only">Close</span>
        </button>

        {/* Progress dots */}
        <div className="mb-6 flex justify-center gap-2">
          {steps.map((_, index) => (
            <div
              key={index}
              className={`h-2 w-2 rounded-full transition-colors ${
                index === currentStep ? 'bg-primary' : 'bg-muted'
              }`}
            />
          ))}
        </div>

        {/* Content */}
        <div className="space-y-6 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <Icon className="h-8 w-8 text-primary" />
          </div>

          <div className="space-y-2">
            <h3 className="text-2xl font-semibold tracking-tight">{currentStepData.title}</h3>
            <p className="text-muted-foreground">{currentStepData.description}</p>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleSkip}
              className="flex-1 hover-elevate active-elevate-2"
              data-testid="button-skip-onboarding"
            >
              Skip
            </Button>
            <Button
              onClick={handleNext}
              className="flex-1 hover-elevate active-elevate-2"
              data-testid="button-next-onboarding"
            >
              {currentStep < 2 ? 'Next' : 'Get Started'}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
