import { Coins } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { formatTokenAmount } from '@/lib/solana';

interface TokenPreviewProps {
  name: string;
  symbol: string;
  description?: string;
  imageUrl?: string;
  supply: string;
  decimals: number;
}

export function TokenPreview({
  name,
  symbol,
  description,
  imageUrl,
  supply,
  decimals,
}: TokenPreviewProps) {
  return (
    <Card className="p-6">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start gap-4">
          <Avatar className="h-16 w-16 rounded-full border-2 border-border">
            {imageUrl ? (
              <AvatarImage src={imageUrl} alt={name} />
            ) : (
              <AvatarFallback className="bg-primary/10">
                <Coins className="h-8 w-8 text-primary" />
              </AvatarFallback>
            )}
          </Avatar>

          <div className="flex-1 space-y-1">
            <h3 className="text-xl font-semibold" data-testid="text-preview-name">
              {name || 'Token Name'}
            </h3>
            <p className="text-lg text-muted-foreground" data-testid="text-preview-symbol">
              ${symbol || 'SYMBOL'}
            </p>
          </div>
        </div>

        {/* Description */}
        {description && (
          <p className="text-sm text-muted-foreground" data-testid="text-preview-description">
            {description}
          </p>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4 rounded-md bg-muted/50 p-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Total Supply</p>
            <p className="text-lg font-semibold" data-testid="text-preview-supply">
              {supply ? formatTokenAmount(supply, decimals) : '0'}
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Decimals</p>
            <p className="text-lg font-semibold" data-testid="text-preview-decimals">
              {decimals}
            </p>
          </div>
        </div>

        {/* Mock market info */}
        <div className="space-y-2 border-t pt-4">
          <p className="text-xs font-medium text-muted-foreground">DEX Preview</p>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Market Cap</span>
              <span className="font-medium">-</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">24h Volume</span>
              <span className="font-medium">-</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Holders</span>
              <span className="font-medium">1</span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
