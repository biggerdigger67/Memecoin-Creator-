import { useState, useEffect } from 'react';
import { DollarSign, Info } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { calculateTotalFee, formatSolAmount, ADVANCED_FEES, BASE_FEE } from '@/lib/solana';
import { useQuery } from '@tanstack/react-query';

interface FeeCounterProps {
  options: {
    hasCustomCreator?: boolean;
    hasVanityAddress?: boolean;
    hasMultiWallet?: boolean;
    hasDexTools?: boolean;
    freezeAuthorityRevoked?: boolean;
    mintAuthorityRevoked?: boolean;
    updateAuthorityRevoked?: boolean;
  };
  onProceed?: () => void;
  showProceedButton?: boolean;
  proceedLabel?: string;
  proceedDisabled?: boolean;
}

export function FeeCounter({
  options,
  onProceed,
  showProceedButton = false,
  proceedLabel = 'Proceed to Payment',
  proceedDisabled = false,
}: FeeCounterProps) {
  const totalSol = calculateTotalFee(options);

  // Fetch SOL/USD price from CoinGecko
  const { data: solPrice } = useQuery({
    queryKey: ['/api/sol-price'],
    refetchInterval: 60000, // Refetch every minute
  });

  const usdValue = solPrice?.solana?.usd ? totalSol * solPrice.solana.usd : null;

  const feeItems = [
    { label: 'Base Token Creation', amount: BASE_FEE, included: true },
    { label: 'Custom Creator Info', amount: ADVANCED_FEES.customCreator, included: options.hasCustomCreator },
    { label: 'Vanity Address', amount: ADVANCED_FEES.vanityAddress, included: options.hasVanityAddress },
    { label: 'Multi-Wallet Distribution', amount: ADVANCED_FEES.multiWallet, included: options.hasMultiWallet },
    { label: 'DEXTools Integration', amount: ADVANCED_FEES.dexTools, included: options.hasDexTools },
    { label: 'Revoke Freeze Authority', amount: ADVANCED_FEES.revokeFreeze, included: options.freezeAuthorityRevoked },
    { label: 'Revoke Mint Authority', amount: ADVANCED_FEES.revokeMint, included: options.mintAuthorityRevoked },
    { label: 'Revoke Update Authority', amount: ADVANCED_FEES.revokeUpdate, included: options.updateAuthorityRevoked },
  ];

  return (
    <Card className="sticky top-20 p-6">
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold">Fee Summary</h3>
        </div>

        <Separator />

        {/* Fee breakdown */}
        <div className="space-y-3">
          {feeItems.map(
            (item, index) =>
              item.included && (
                <div key={index} className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{item.label}</span>
                  <span className="font-medium">{formatSolAmount(item.amount)}</span>
                </div>
              )
          )}
        </div>

        <Separator />

        {/* Total */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-lg font-semibold">Total</span>
            <span className="text-2xl font-bold text-primary" data-testid="text-total-fee">
              {formatSolAmount(totalSol)}
            </span>
          </div>

          {usdValue && (
            <div className="flex items-center justify-end gap-1">
              <span className="text-sm text-muted-foreground" data-testid="text-usd-equivalent">
                ≈ ${usdValue.toFixed(2)} USD
              </span>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-3 w-3 text-muted-foreground" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="text-xs">Price updated from CoinGecko</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          )}
        </div>

        {/* Proceed button */}
        {showProceedButton && (
          <>
            <Separator />
            <Button
              onClick={onProceed}
              disabled={proceedDisabled}
              className="w-full hover-elevate active-elevate-2"
              data-testid="button-proceed-payment"
            >
              {proceedLabel}
            </Button>
          </>
        )}
      </div>
    </Card>
  );
}
