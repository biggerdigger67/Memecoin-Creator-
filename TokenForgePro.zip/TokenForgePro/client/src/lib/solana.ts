// Solana utility functions and constants
export const SOLANA_NETWORK = 'mainnet-beta';
export const BASE_FEE = 0.3;

export const ADVANCED_FEES = {
  customCreator: 0.1,
  vanityAddress: 0.1,
  multiWallet: 0.1,
  dexTools: 3.0,
  revokeFreeze: 0.1,
  revokeMint: 0.1,
  revokeUpdate: 0.1,
} as const;

export function calculateTotalFee(options: {
  hasCustomCreator?: boolean;
  hasVanityAddress?: boolean;
  hasMultiWallet?: boolean;
  hasDexTools?: boolean;
  freezeAuthorityRevoked?: boolean;
  mintAuthorityRevoked?: boolean;
  updateAuthorityRevoked?: boolean;
}): number {
  let total = BASE_FEE;
  
  if (options.hasCustomCreator) total += ADVANCED_FEES.customCreator;
  if (options.hasVanityAddress) total += ADVANCED_FEES.vanityAddress;
  if (options.hasMultiWallet) total += ADVANCED_FEES.multiWallet;
  if (options.hasDexTools) total += ADVANCED_FEES.dexTools;
  if (options.freezeAuthorityRevoked) total += ADVANCED_FEES.revokeFreeze;
  if (options.mintAuthorityRevoked) total += ADVANCED_FEES.revokeMint;
  if (options.updateAuthorityRevoked) total += ADVANCED_FEES.revokeUpdate;
  
  return total;
}

export function formatSolAmount(amount: number): string {
  return `${amount.toFixed(2)} SOL`;
}

export function formatTokenAmount(amount: string | number, decimals: number = 9): string {
  const num = typeof amount === 'string' ? parseFloat(amount) : amount;
  if (isNaN(num)) return '0';
  
  // Format with commas
  return new Intl.NumberFormat('en-US', {
    maximumFractionDigits: decimals,
  }).format(num);
}

export function truncateAddress(address: string, startChars: number = 4, endChars: number = 4): string {
  if (!address) return '';
  if (address.length <= startChars + endChars) return address;
  return `${address.slice(0, startChars)}...${address.slice(-endChars)}`;
}

export function validateSolanaAddress(address: string): boolean {
  // Basic validation: Solana addresses are base58 encoded and typically 32-44 characters
  const base58Regex = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
  return base58Regex.test(address);
}

export function isValidVanityPrefix(prefix: string): boolean {
  // Vanity prefix must be valid base58 characters and max 4 chars
  if (!prefix || prefix.length > 4) return false;
  const base58Regex = /^[1-9A-HJ-NP-Za-km-z]+$/;
  return base58Regex.test(prefix);
}
