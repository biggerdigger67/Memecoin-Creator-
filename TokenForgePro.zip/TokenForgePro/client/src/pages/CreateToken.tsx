import { useState } from 'react';
import { useWallet } from '@/contexts/WalletContext';
import { WizardProgress } from '@/components/WizardProgress';
import { FeeCounter } from '@/components/FeeCounter';
import { StepConnect } from '@/components/wizard/StepConnect';
import { StepCustomize } from '@/components/wizard/StepCustomize';
import { StepAdvanced } from '@/components/wizard/StepAdvanced';
import { StepMint } from '@/components/wizard/StepMint';
import { Button } from '@/components/ui/button';
import { ChevronLeft } from 'lucide-react';

export interface TokenFormData {
  name: string;
  symbol: string;
  description: string;
  decimals: number;
  supply: string;
  imageFile: File | null;
  imagePreview: string;
  
  // Advanced options
  hasCustomCreator: boolean;
  customCreatorAddress: string;
  
  hasVanityAddress: boolean;
  vanityPrefix: string;
  
  hasMultiWallet: boolean;
  recipientWallets: { address: string; amount: string }[];
  
  hasDexTools: boolean;
  dexToolsTwitter: string;
  dexToolsTelegram: string;
  dexToolsWebsite: string;
  dexToolsBanner: File | null;
  
  freezeAuthorityRevoked: boolean;
  mintAuthorityRevoked: boolean;
  updateAuthorityRevoked: boolean;
}

const WIZARD_STEPS = [
  { id: 1, title: 'Connect', description: 'Connect your wallet' },
  { id: 2, title: 'Customize', description: 'Token details' },
  { id: 3, title: 'Advanced', description: 'Optional features' },
  { id: 4, title: 'Mint', description: 'Create token' },
];

export default function CreateToken() {
  const { isConnected } = useWallet();
  const [currentStep, setCurrentStep] = useState(isConnected ? 2 : 1);
  const [formData, setFormData] = useState<TokenFormData>({
    name: '',
    symbol: '',
    description: '',
    decimals: 9,
    supply: '',
    imageFile: null,
    imagePreview: '',
    
    hasCustomCreator: false,
    customCreatorAddress: '',
    
    hasVanityAddress: false,
    vanityPrefix: '',
    
    hasMultiWallet: false,
    recipientWallets: [{ address: '', amount: '' }],
    
    hasDexTools: false,
    dexToolsTwitter: '',
    dexToolsTelegram: '',
    dexToolsWebsite: '',
    dexToolsBanner: null,
    
    freezeAuthorityRevoked: false,
    mintAuthorityRevoked: false,
    updateAuthorityRevoked: false,
  });

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const updateFormData = (updates: Partial<TokenFormData>) => {
    setFormData((prev) => ({ ...prev, ...updates }));
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <StepConnect onNext={handleNext} />;
      case 2:
        return (
          <StepCustomize
            formData={formData}
            updateFormData={updateFormData}
            onNext={handleNext}
            onBack={handleBack}
          />
        );
      case 3:
        return (
          <StepAdvanced
            formData={formData}
            updateFormData={updateFormData}
            onNext={handleNext}
            onBack={handleBack}
          />
        );
      case 4:
        return (
          <StepMint
            formData={formData}
            onBack={handleBack}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto max-w-7xl px-4 py-8">
        {/* Progress */}
        <div className="mb-8">
          <WizardProgress currentStep={currentStep} steps={WIZARD_STEPS} />
        </div>

        {/* Content */}
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main wizard area */}
          <div className="lg:col-span-2">
            {renderStep()}
          </div>

          {/* Fee counter (shown from step 2 onwards) */}
          {currentStep >= 2 && (
            <div className="lg:col-span-1">
              <FeeCounter
                options={{
                  hasCustomCreator: formData.hasCustomCreator,
                  hasVanityAddress: formData.hasVanityAddress,
                  hasMultiWallet: formData.hasMultiWallet,
                  hasDexTools: formData.hasDexTools,
                  freezeAuthorityRevoked: formData.freezeAuthorityRevoked,
                  mintAuthorityRevoked: formData.mintAuthorityRevoked,
                  updateAuthorityRevoked: formData.updateAuthorityRevoked,
                }}
                showProceedButton={currentStep === 3}
                onProceed={handleNext}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
