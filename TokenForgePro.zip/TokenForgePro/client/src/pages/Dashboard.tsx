import { ExternalLink, Coins, Loader2 } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useQuery } from '@tanstack/react-query';
import { useWallet } from '@/contexts/WalletContext';
import { Link } from 'wouter';
import { truncateAddress, formatTokenAmount } from '@/lib/solana';
import type { Token } from '@shared/schema';

export default function Dashboard() {
  const { isConnected } = useWallet();

  const { data: tokens, isLoading } = useQuery<Token[]>({
    queryKey: ['/api/user/tokens'],
    enabled: isConnected,
  });

  if (!isConnected) {
    return (
      <div className="container mx-auto max-w-4xl px-4 py-16">
        <Card className="p-12 text-center">
          <div className="space-y-4">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <Coins className="h-8 w-8 text-primary" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-bold tracking-tight">Connect Your Wallet</h2>
              <p className="text-muted-foreground">
                Connect your Phantom Wallet to view your created tokens
              </p>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="container mx-auto max-w-6xl px-4 py-16">
        <div className="flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-6xl px-4 py-8">
      {/* Header */}
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">My Tokens</h1>
          <p className="text-muted-foreground">
            View and manage all your created SPL tokens
          </p>
        </div>
        <Link href="/">
          <Button className="hover-elevate active-elevate-2" data-testid="button-create-new">
            Create New Token
          </Button>
        </Link>
      </div>

      {/* Tokens grid */}
      {!tokens || tokens.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="space-y-4">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-muted">
              <Coins className="h-8 w-8 text-muted-foreground" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-semibold">No tokens yet</h3>
              <p className="text-muted-foreground">
                Create your first SPL token to get started
              </p>
            </div>
            <Link href="/">
              <Button className="hover-elevate active-elevate-2">
                Create Your First Token
              </Button>
            </Link>
          </div>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {tokens.map((token) => (
            <Card key={token.id} className="overflow-hidden hover-elevate" data-testid={`card-token-${token.id}`}>
              <div className="p-6">
                <div className="space-y-4">
                  {/* Token header */}
                  <div className="flex items-start gap-4">
                    <Avatar className="h-12 w-12 rounded-full border-2 border-border">
                      {token.imageUri ? (
                        <AvatarImage src={token.imageUri} alt={token.name} />
                      ) : (
                        <AvatarFallback className="bg-primary/10">
                          <Coins className="h-6 w-6 text-primary" />
                        </AvatarFallback>
                      )}
                    </Avatar>

                    <div className="flex-1 space-y-1">
                      <h3 className="font-semibold" data-testid={`text-token-name-${token.id}`}>
                        {token.name}
                      </h3>
                      <p className="text-sm text-muted-foreground" data-testid={`text-token-symbol-${token.id}`}>
                        ${token.symbol}
                      </p>
                    </div>
                  </div>

                  {/* Description */}
                  {token.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {token.description}
                    </p>
                  )}

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-3 rounded-md bg-muted/50 p-3">
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Supply</p>
                      <p className="text-sm font-semibold">
                        {formatTokenAmount(token.supply, token.decimals)}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Decimals</p>
                      <p className="text-sm font-semibold">{token.decimals}</p>
                    </div>
                  </div>

                  {/* Mint address */}
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Mint Address</p>
                    <p className="font-mono text-xs font-medium">
                      {truncateAddress(token.mintAddress, 6, 6)}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(`https://solscan.io/token/${token.mintAddress}`, '_blank')}
                      className="flex-1 hover-elevate active-elevate-2"
                      data-testid={`button-view-explorer-${token.id}`}
                    >
                      <ExternalLink className="mr-2 h-3 w-3" />
                      Explorer
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
