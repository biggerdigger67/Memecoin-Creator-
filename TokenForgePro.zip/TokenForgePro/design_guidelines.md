# TokenForge Pro - Design Guidelines

## Design Approach
**System-Based Approach**: Utility-focused application prioritizing trust, clarity, and efficiency for financial transactions on Solana blockchain. Drawing from modern fintech and Web3 design patterns that emphasize security and professionalism.

**Core Principles**:
- Trust through minimalism: Clean, uncluttered interfaces that convey security
- Clarity over decoration: Every element serves a functional purpose
- Progressive disclosure: Advanced options revealed when needed
- Financial transparency: Clear fee breakdowns at every step

---

## Color Palette

### Light Mode (Primary)
- **Background**: 0 0% 100% (pure white)
- **Surface**: 0 0% 98% (near-white for cards)
- **Border**: 0 0% 90% (light gray)
- **Text Primary**: 0 0% 10% (near-black)
- **Text Secondary**: 0 0% 40% (medium gray)
- **Brand Primary**: 220 70% 50% (subtle blue - trust and technology)
- **Brand Hover**: 220 70% 45% (darker blue)
- **Success**: 142 71% 45% (blockchain green)
- **Warning**: 38 92% 50% (fee alerts)
- **Error**: 0 84% 60% (transaction failures)

### Dark Mode
- **Background**: 0 0% 8% (deep charcoal)
- **Surface**: 0 0% 12% (card backgrounds)
- **Border**: 0 0% 20% (subtle borders)
- **Text Primary**: 0 0% 95% (off-white)
- **Text Secondary**: 0 0% 65% (light gray)
- (Brand colors remain consistent)

**Critical**: No gradients, no neon effects, no purple/pink accents. Maintain subdued, professional palette throughout.

---

## Typography

- **Primary Font**: Inter (via Google Fonts CDN)
- **Headings**: 
  - H1: 2.5rem (40px), font-weight 700, tracking-tight
  - H2: 2rem (32px), font-weight 600
  - H3: 1.5rem (24px), font-weight 600
  - H4: 1.25rem (20px), font-weight 500
- **Body**: 1rem (16px), font-weight 400, line-height 1.6
- **Small**: 0.875rem (14px) for labels and hints
- **Mono**: Use system mono for wallet addresses and token amounts

---

## Layout System

**Spacing**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20 for consistent rhythm
- Component padding: p-6 to p-8
- Section spacing: space-y-6 to space-y-8
- Container max-width: max-w-6xl for main content
- Wizard form: max-w-2xl centered

**Grid**:
- Mobile: Single column, full-width cards
- Tablet/Desktop: Wizard left (60%), fee summary right (40%) in sticky sidebar

---

## Component Library

### Navigation
- Minimal header: Logo left, Wallet connection button right
- No traditional navigation menu - single-purpose application
- Fixed position with subtle bottom border

### Wizard Interface
- **Progress Indicator**: Horizontal stepper showing 4 steps with checkmarks for completed steps
- **Step Container**: White card with subtle shadow, rounded corners (rounded-lg)
- **Form Fields**: 
  - Labels above inputs (font-weight 500)
  - Input borders: 1px solid gray-300, focus:ring-2 ring-blue-500
  - Help text below in gray-500 (text-sm)
- **Token Preview Card**: Mock DEX listing card showing live token metadata as user types

### Advanced Options
- **Accordion Layout**: Expandable sections with clean + icon indicators
- **Toggle Switches**: iOS-style toggles for authority revokes (always visible)
- **Fee Tags**: Small pill-shaped badges showing "+0.1 SOL" next to each option

### Dynamic Fee Counter
- **Fixed Sidebar** (desktop): Sticky right panel with:
  - Total SOL cost (large, bold)
  - Itemized fee breakdown (base + each modifier)
  - USD equivalent in smaller text
  - "Proceed to Payment" CTA button
- **Bottom Bar** (mobile): Fixed bottom with total and CTA

### Buttons
- **Primary**: Blue background, white text, medium shadow
- **Secondary**: White background, gray border, gray-700 text
- **Outline on Images**: White border, backdrop-blur-md, semi-transparent background
- Sizes: px-6 py-3 for primary actions, px-4 py-2 for secondary

### Onboarding Modal
- **First Visit Only**: Subtle slide-in from bottom or center fade-in
- **3-Step Teaser**: Icon + short text for each step, minimal design
- **Dismiss Button**: Small X in top-right, "Don't show again" checkbox
- Semi-transparent backdrop (backdrop-blur-sm)

### Error Handling
- **Toast Notifications**: Slide from top-right
- Success: Green accent with checkmark icon
- Error: Red accent with alert icon
- Warning: Orange accent
- Duration: 5 seconds with dismiss option

### Icons
- **Library**: Heroicons (via CDN)
- Usage: 24px for headers, 20px for inline, 16px for small contexts
- Style: Outline variant for consistency

---

## Specific Screen Guidelines

### Landing/Connect Wallet (Step 1)
- Centered content with hero heading
- Clear explanation of TokenForge Pro purpose
- Large "Connect Phantom Wallet" button
- Trust indicators: "Mainnet Verified" badge, transaction count

### Customize Token (Step 2)
- Left: Form fields (name, symbol, decimals, description, image upload)
- Right: Live preview card updating in real-time
- Image upload: Drag-drop zone with preview
- Character counters for inputs with limits

### Advanced Options (Step 3)
- Three revoke authority toggles prominently displayed
- Accordion sections below:
  - Creator modifications
  - Vanity address generator
  - Multi-wallet distribution
  - DEXTools integration
- Each section shows fee and expands to reveal controls

### Payment & Mint (Step 4)
- Final confirmation screen
- Complete fee breakdown
- Wallet balance check with warning if insufficient
- Large "Mint Token" button
- Progress indicator during minting
- Success screen with blockchain explorer link

### User Dashboard
- Grid of created tokens (3 columns desktop, 1 mobile)
- Each card: Token image, name, symbol, mint address (truncated)
- "View on Explorer" link
- Filter/search for many tokens

---

## Accessibility
- Minimum contrast ratio: 4.5:1 for text
- All interactive elements keyboard-navigable
- Focus indicators: 2px blue ring
- ARIA labels for icon buttons
- Screen reader announcements for dynamic fee updates

---

## Animations
**Minimal Use Only**:
- Button hover: subtle scale (scale-105) and shadow increase
- Modal entry: fade-in with slight slide-up (duration-200)
- Toast notifications: slide-in from side (duration-300)
- Loading states: Simple spinner, no elaborate animations
- **No**: Gradient animations, glow effects, parallax, or scroll-triggered effects

---

## Images
**No Hero Image**: This is a utility application, not a marketing site. Focus on functionality from the first pixel.

**Token Preview Image**: User-uploaded token logo displayed in the mock DEX card preview (circular, 64px diameter)

**Trust Badges**: Small SVG logos for "Solana Mainnet", "IPFS Verified" if needed